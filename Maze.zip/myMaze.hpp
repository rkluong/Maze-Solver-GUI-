#ifndef MYMAZE_HPP
#define MYMAZE_HPP

#include "MazeGenerator.hpp"
#include "Direction.hpp"
#include <vector>
class MyMazeGenerator : public MazeGenerator
{
public:
    virtual void generateMaze(Maze& maze);
};

//used to store the X, Y values to pass into a function mazeGenerator
class cell{
public:
	//accessor methods
	//returns the X coordinate value
	int get_x();
	//returns the Y coordinate value
	int get_y();
	//mutator methods
	//sets X coordinate to x_val passed in
	void set_x(int x_val);
	//sets Y coordinate to y_val passed in
	void set_y(int y_val);
	//prints the coordinate for view
	void print_coord();
private:
	int x;
	int y;
};

//the direction is passed in as an int and returns 
//a Direction object used to move.
Direction getDirection(int way);
//checks the direction if it is valid to move
//used in the dfs_search to build the maze and search for valid directions
bool check_direction(int way, cell cur_cell, Maze& maze);
//checks every cell up, down, left and right used to check if there are 
//unvisited cells in all four directions
bool check_unvisited(cell cur_cell, Maze& maze);
//recursive method to build the maze using helper functions written above
//to check for valid move
void dfs_search(cell cur_cell, Maze& maze, cell** maze_cells);
//sets the vector to the dimensions of the maze
void set_vector(std::vector<std::vector<bool>> *vec, Maze& maze);
//resets the bool vector used to keep track whether the cell has been visited
void reset_vector(std::vector<std::vector<bool>> *vec);




#endif // MYMAZE_HPP