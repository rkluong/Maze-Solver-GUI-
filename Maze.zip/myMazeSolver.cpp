#include "myMazeSolver.hpp"
#include <ics46/factory/DynamicFactory.hpp>
#include "Direction.hpp"
#include "myMaze.hpp"

#include <vector>
#include <utility>
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <time.h>

//pair (X,Y) X = 0,Y = 1
ICS46_DYNAMIC_FACTORY_REGISTER(MazeSolver, MyMazeSolver, "My Maze Solver(REQUIRED)");
std::vector<std::vector<bool>> visit;

//resizes 2d vector to the height and width of the maze
void set_vector(std::vector<std::vector<bool>> *vec, const Maze& maze){
	vec->resize(maze.getHeight());
	for(std::vector<std::vector<bool>>::iterator row = vec->begin(); row != vec->end(); row++){
		row->resize(maze.getWidth(), 0);
	}
}

//method rewritten to work with pairs
//checks in the direction passed in as an int to see if a wall exists
//returns true if there is no wall between the current point and the cell
//in the direction and false otherwise.
bool check_direction(int way, std::pair<int, int> current, const Maze& maze){
	switch(way){
		//up
		case 0:
			if(std::get<1>(current)-1 >= 0)
				return ( !maze.wallExists(std::get<0>(current), std::get<1>(current), getDirection(0)));
			return false;
		//down
		case 1:
			if(std::get<1>(current) + 1 < maze.getHeight())
				return (!maze.wallExists(std::get<0>(current), std::get<1>(current), getDirection(1)));
			return false;
		//left
		case 2:
			if(std::get<0>(current)-1 >= 0)
				return (!maze.wallExists(std::get<0>(current), std::get<1>(current), getDirection(2)));
			return false;
		//right
		case 3:
			if(std::get<0>(current)+1 < maze.getWidth())
				return (!maze.wallExists(std::get<0>(current), std::get<1>(current), getDirection(3)));
			return false;
	}	
	return false;
}

//recursive method to solve the maze
//method check for valid move in every direction before making a move
//if the move is valid it will make a move and check if the maze is complete
//returns if the mazeSolution is complete
void solve(const Maze& maze, MazeSolution& mazeSolution)
{
	int x = std::get<0>(mazeSolution.getCurrentCell());
	int y = std::get<1>(mazeSolution.getCurrentCell());
	visit[y][x] = true;
	std::cout << "(X,Y) = " << "( " << std::get<0>(mazeSolution.getCurrentCell()) << ", " << std::get<1>(mazeSolution.getCurrentCell()) << ")" << std::endl;
	if(mazeSolution.isComplete()){
		return;
	}
	else{
		//down
		if(check_direction(1, mazeSolution.getCurrentCell(), maze)){
			if(!visit[y+1][x]){
				mazeSolution.extend(getDirection(1));
			 	solve(maze, mazeSolution);
			}
		}
		if(mazeSolution.isComplete()){
			return;
		}
		//right
		if(check_direction(3, mazeSolution.getCurrentCell(), maze)){
			if(!visit[y][x+1]){
				mazeSolution.extend(getDirection(3));
				solve(maze, mazeSolution);
			}
		}
	
		if(mazeSolution.isComplete()){
			return;
		}
		//up
		if(check_direction(0, mazeSolution.getCurrentCell(), maze)){
			if(!visit[y-1][x]){
				mazeSolution.extend(getDirection(0));
				solve(maze, mazeSolution);
			}
		}
		if(mazeSolution.isComplete()){
			return;
		}
		//left
		if(check_direction(2, mazeSolution.getCurrentCell(), maze)){
			if(!visit[y][x-1]){ 
				mazeSolution.extend(getDirection(2));
				solve(maze, mazeSolution);
			}
		}
		if(mazeSolution.isComplete()){
			return;
		}	
		if(!mazeSolution.isComplete())
			mazeSolution.backUp();
	
	}	
		
}
//Solving the maze
void MyMazeSolver::solveMaze(const Maze& maze, MazeSolution& mazeSolution)
{
	set_vector(&visit, maze);
	solve(maze, mazeSolution);
	reset_vector(&visit);
}