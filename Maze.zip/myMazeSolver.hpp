#ifndef MYMAZESOLVER_HPP
#define MYMAZESOLVER_HPP
#include <utility>
#include "MazeSolver.hpp"
#include "Maze.hpp"
#include "MazeSolution.hpp"

class Maze;
class MazeSolution;

class MyMazeSolver : public MazeSolver
{
public:
	virtual void solveMaze(const Maze& maze, MazeSolution& mazeSolution);
};

//set up the 2d vector row and column to the maze height and maze width
void set_vector(std::vector<std::vector<bool>> *vec, const Maze& maze);
//takes in the movement enum and checks if there is a wall in that direction
//from the current point passed in.  Method returns false if there is a wall
//in the direction and true if there is no wall.
//way: 0 = up, 1 = down, 2 = left, 3 = right
bool check_direction(int way, std::pair<int, int> current, const Maze& maze);
//implementation of the recursive method that solves the maze use first search depth algorithm
void solve(const Maze& maze, MazeSolution& mazeSolution);

#endif // MYMAZESOLVER_HPP