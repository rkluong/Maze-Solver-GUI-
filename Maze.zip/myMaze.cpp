#include "myMaze.hpp"
#include "Maze.hpp"
#include <ics46/factory/DynamicFactory.hpp>
#include "Direction.hpp"
#include <iostream>
#include <vector>
#include <time.h>
#include <stack>	
#include <stdlib.h>
#include <stdio.h>

std::vector<std::vector<bool>> cell_visit;
//its my std::stack to store the cells
std::stack<cell> mystack;
ICS46_DYNAMIC_FACTORY_REGISTER(MazeGenerator, MyMazeGenerator, "My Maze Generator(REQUIRED)");
//returns the X coordinate of a cell
int cell::get_x(){
	return x;
}
//returns the Y coordinate of a cell 
int cell::get_y(){
	return y;
}

//sets the x coord to the x_val passed in
void cell::set_x(int x_val){
	x = x_val;
}

//sets the y coord to the y_val passed in
void cell::set_y(int y_val){
	y = y_val;
}

//displays the coordinate(X,Y)
void cell::print_coord(){
	std::cout << "coordinate ( " << x << ", " << y << ")" << std::endl;
}

//returns the direction passed in as an int
Direction getDirection(int way){
	return static_cast<Direction>(way);
}


//depending on which direction and if the direction is out of bounds
// we need to check the adjacent cell in that direction
bool check_direction(int way, cell cur_cell, Maze& maze){
	
	switch(way){
		//up
			case 0:
				if(cur_cell.get_y() - 1 >= 0)
					return !cell_visit[cur_cell.get_y()-1][cur_cell.get_x()];
				std::cout << "testing block 1" << std::endl;
				return false;
		//down
			case 1:
				if(cur_cell.get_y() + 1 <  maze.getHeight())
					return !cell_visit[cur_cell.get_y()+1][cur_cell.get_x()];
				return false;
		//left
			case 2:
				if(cur_cell.get_x() - 1 >= 0)
					return !cell_visit[cur_cell.get_y()][cur_cell.get_x()-1];
				std::cout << "testing block 2" << std::endl;
				return false;  
		//right	
			case 3:
				if(cur_cell.get_x() + 1 < maze.getWidth())
					return !cell_visit[cur_cell.get_y()][cur_cell.get_x()+1];
				
				return false;
	}
	return false;
}

//checks adjacent cells if they have been visited
bool check_unvisited(cell cur_cell, Maze& maze){
	for(int i = 0; i < 4; i++){
		if(check_direction(i, cur_cell, maze))
			return true;
	}
	return false;
}

//method is recursive searching for valid movement to build the maze
void dfs_search(cell cur_cell, Maze& maze, cell** maze_cells){
	//current cell needs to be mark true
	cell_visit[cur_cell.get_y()][cur_cell.get_x()] = true;
	mystack.push(maze_cells[cur_cell.get_y()][cur_cell.get_x()]);
	if(cur_cell.get_x() == maze.getWidth() && cur_cell.get_y() == maze.getHeight())
		return;
	//check all adjacent cells
	while(check_unvisited(cur_cell, maze)){	
		int way = rand() % 4;
		if(check_direction(way, cur_cell, maze)){
			switch(way){
				//break top wall
				case 0:
					maze.removeWall(cur_cell.get_x(), cur_cell.get_y(), getDirection(way));
					dfs_search(maze_cells[cur_cell.get_y()-1][cur_cell.get_x()], maze, maze_cells);
					break;
				//break bottom wall
				case 1:
					maze.removeWall(cur_cell.get_x(), cur_cell.get_y(), getDirection(way));
					dfs_search(maze_cells[cur_cell.get_y()+1][cur_cell.get_x()], maze, maze_cells);
					break;
				//break left wall
				case 2:
					maze.removeWall(cur_cell.get_x(), cur_cell.get_y(), getDirection(way));
					dfs_search(maze_cells[cur_cell.get_y()][cur_cell.get_x()-1], maze, maze_cells);
					break;
				//break right wall
				case 3:
					maze.removeWall(cur_cell.get_x(), cur_cell.get_y(), getDirection(way));
					dfs_search(maze_cells[cur_cell.get_y()][cur_cell.get_x()+1], maze, maze_cells);
					break;
			}
		}
		else if(!mystack.empty()){
			dfs_search(mystack.top(), maze, maze_cells);
		}
	}
}		
			

//resizes 2d vector to the dimensions of the maze
void set_vector(std::vector<std::vector<bool>> *vec, Maze& maze){
	vec->resize(maze.getHeight());
	for(std::vector<std::vector<bool>>::iterator row = vec->begin(); row != vec->end(); row++){
		row->resize(maze.getWidth(), 0);
	}
}

//this resets the cells visited vector before generating a new maze
void reset_vector(std::vector<std::vector<bool>> *vec){
	for(std::vector<std::vector<bool>>::iterator row = vec->begin(); row != vec->end(); row++){
		std::fill(row->begin(), row->end(), 0);
		}
}
//Generate the maze
void MyMazeGenerator::generateMaze(Maze& maze){
	maze.removeAllWalls();
	maze.addAllWalls();
	//set up vectors
	set_vector(&cell_visit, maze);
	
 	
	//set up maze_cells
	cell** maze_cells = new cell*[maze.getHeight()];
	for(int row = 0; row < maze.getHeight(); row++){
		maze_cells[row] = new cell[maze.getWidth()];
		for(int col = 0; col < maze.getWidth(); col++){
			cell cur_cell;
			cur_cell.set_x(col);
			cur_cell.set_y(row);
			maze_cells[row][col] = cur_cell;
			maze_cells[row][row].print_coord();
		}
	}


	//random seed generator
	srand (time(NULL));
	//starting point
	cell cur_cell;
	cur_cell.set_x(0);
	cur_cell.set_y(0);
	dfs_search(cur_cell, maze, maze_cells);
	reset_vector(&cell_visit);
	for(int i = 0; i < maze.getHeight(); i++){
		delete maze_cells[i];
	}
	delete [] maze_cells;

}
